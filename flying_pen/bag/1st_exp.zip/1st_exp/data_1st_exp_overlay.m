%% CSV overlay normal/force analysis (1009 first experiment)
% Put this script beside the cropped CSV files and run it. Every CSV in the
% script directory is loaded; each recording keeps its own time origin.
clear; close all; clc;

%% Configuration and CSV loading
% Values copied from su_params.yaml on 2026-10-10. This script deliberately
% does not read the YAML file at run time.
% Prefer the file currently open/running in MATLAB Editor. Fall back cleanly
% for command-line execution and copied folders.
data_dir = activeScriptDirectory();
fprintf('CSV selection folder: %s\n',data_dir);
global_xlim = [0 62];                  % [s], e.g. [10 60]; [] uses full time range
cfg.beta = 3.0;                    % su_position.normBeta [1/s]
cfg.gamma = 2.5;                   % su_position.normGamma [1/s]
cfg.eps_v = 0.0004;                % su_position.normEpsV [m^2/s^2]
cfg.eps_f = 0.005;                 % su_position.normEpsF [N]
% Five-section surface fitted to wind0_*_trimmed.csv (0-60 s).
% Robust spatial-bin fit RMS: 0.99 mm in the X-Z plane. The two arc angles
% are independent; a common radius was better conditioned than two radii.
cfg.origin = [1.376816 0.020818 0.840479]; % fitted [x,y,z] origin [m]
cfg.initial_tangent_deg = 112.1065; % fitted lower-plane tangent [deg]
cfg.plane_lengths = [0.098803 0.294582 0.105241]; % lower/middle/upper [m]
cfg.curve_radius = 0.711997;        % fitted common arc radius [m]
cfg.turn_angles_deg = [21.8979 29.4695]; % lower/upper arc angles [deg]
cfg.true_normal_hold_time = 54.0;   % [s], hold endpoint normal after this time

% Select one CSV for a single plot, or Ctrl/Shift-select multiple CSV files
% to overlay them on the same axes.
[selected_files,selected_path] = uigetfile( ...
    {'*.csv','Normal-estimator CSV files (*.csv)'}, ...
    'Select one or more CSV files',data_dir,'MultiSelect','on');
if isequal(selected_files,0), return; end
if ischar(selected_files) || isstring(selected_files)
    selected_files = cellstr(selected_files);
end
selected_files = sort(selected_files);
records = struct([]);
for file_index = 1:numel(selected_files)
    csv_path = fullfile(selected_path,selected_files{file_index});
    fprintf('Loading %s\n',csv_path);
    table_data = readtable(csv_path,detectImportOptions(csv_path,'Delimiter',','));
    record = prepareRecord(table_data,selected_files{file_index},cfg);
    if file_index == 1, records = record; else, records(file_index) = record; end
end
% Display one common surface at the mean fitted pose; true normals remain
% based on each recording's own fitted pose.
fittedOrigins=vertcat(records.geometry_cfg);
fittedOrigins=vertcat(fittedOrigins.origin);
cfg.origin=mean(fittedOrigins,1);
fprintf(['Loaded %d CSV files | beta=%.4g, gamma=%.4g, ' ...
    'eps_v=%.4g, eps_f=%.4g\n'],numel(records),cfg.beta,cfg.gamma,cfg.eps_v,cfg.eps_f);

dataset_labels = repmat({''},numel(records),1);
if numel(records) > 1
    for file_index = 1:numel(records)
        dataset_labels{file_index} = extractWindLabel(records(file_index).label);
    end
end

axis_names = {'x','y','z'};
record_colors = lines(numel(records));
method_names = {'$\hat{f}_{\ell}$, velocity correction ON', ...
    '$\bar{f}_{\ell}$, velocity correction ON', ...
    '$\hat{f}_{c}$, velocity correction ON', ...
    '$\hat{f}_{c}$, velocity correction OFF'};
method_styles = {':','--','-','-.'};
method_widths = [1.8 1.8 2.4 1.8];

%% 1. Tangential velocity t1/t2 and normal force Fn
tracking_ylim = {[-0.2 0.2],[-0.2 0.2],[0 0.04]}; % {t1,t2,Fn}; use [] for auto
figure('Name','Tangential velocity and normal force','Color','w','Position',[80 90 1350 850]);
tracking_axes = gobjects(3,1);
tracking_names = {'t1 velocity','t2 velocity','normal force Fn'};
tracking_units = {'v_{t1} [m/s]','v_{t2} [m/s]','F_n [N]'};
for component = 1:3
    tracking_axes(component) = subplot(3,1,component); hold on;
    for file_index = 1:numel(records)
        if component == 1
            desired = records(file_index).u1_des;
            measured = records(file_index).v_t1;
        elseif component == 2
            desired = records(file_index).u2_des;
            measured = records(file_index).v_t2;
        else
            desired = records(file_index).force_desired;
            measured = records(file_index).fn_hat;
        end
        plot(records(file_index).t,desired,'--','Color', ...
            curveColor(record_colors(file_index,:),1,numel(records)), ...
            'LineWidth',1.6,'DisplayName',legendLabel(dataset_labels{file_index},'desired'));
        plot(records(file_index).t,measured,'-','Color', ...
            curveColor(record_colors(file_index,:),2,numel(records)), ...
            'LineWidth',2.0,'DisplayName',legendLabel(dataset_labels{file_index},'measured'));
    end
    grid on; box on; ylabel(tracking_units{component});
    applyConfiguredYLim(tracking_axes(component),tracking_ylim{component});
    title(tracking_names{component});
    if component == 1, legend('Location','eastoutside','Interpreter','none'); end
end
xlabel(tracking_axes(end),'Time [s]'); linkaxes(tracking_axes,'x');
applyGlobalXLim(tracking_axes,global_xlim);

%% 2. Normal estimation x/y/z: firmware and offline validation variants
normal_ylim = {[-1.1 1.1],[-1.1 1.1],[-1.1 1.1],[0 90]}; % {x,y,z,error angle deg}; [] for auto
figure('Name','Normal estimation overlay','Color','w','Position',[100 80 1350 850]);
normal_axes = gobjects(4,1);
for component = 1:3
    normal_axes(component) = subplot(4,1,component); hold on;
    % Draw every true-normal curve before any estimate so all stay behind.
    for file_index = 1:numel(records)
        plot(records(file_index).t,records(file_index).true_normal(:,component), ...
            'Color',[0.76 0.76 0.76],'LineStyle','-','LineWidth',3.0, ...
            'DisplayName',legendLabel(dataset_labels{file_index},'true normal'));
    end
    for file_index = 1:numel(records)
        normal_set = cat(3,records(file_index).n_velocity_on_fraw, ...
            records(file_index).n_velocity_on_fbar, ...
            records(file_index).n_firmware, ...
            records(file_index).n_velocity_off_fhatc);
        for method = 1:numel(method_names)
            label = legendLabel(dataset_labels{file_index},method_names{method});
            plot(records(file_index).t,normal_set(:,component,method), ...
                'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
                'LineStyle',method_styles{method},'LineWidth',method_widths(method), ...
                'DisplayName',label);
        end
    end
    grid on; box on;
    applyConfiguredYLim(normal_axes(component),normal_ylim{component});
    ylabel(sprintf('n_%s [-]',axis_names{component}));
    if component == 1
        title('Normal Estimation');
        legend('Location','eastoutside','Interpreter','latex');
    end
end
normal_axes(4) = subplot(4,1,4); hold on;
for file_index = 1:numel(records)
    normal_set = cat(3,records(file_index).n_velocity_on_fraw, ...
        records(file_index).n_velocity_on_fbar, ...
        records(file_index).n_firmware, ...
        records(file_index).n_velocity_off_fhatc);
    for method = 1:numel(method_names)
        angle_error = angleBetweenRowsDeg(normal_set(:,:,method), ...
            records(file_index).true_normal);
        plot(records(file_index).t,angle_error, ...
            'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
            'LineStyle',method_styles{method},'LineWidth',method_widths(method), ...
            'DisplayName',legendLabel(dataset_labels{file_index},method_names{method}));
    end
end
grid on; box on; ylabel('angle [deg]'); title('Angle between estimated and true normal');
applyConfiguredYLim(normal_axes(4),normal_ylim{4});
legend('Location','eastoutside','Interpreter','latex');
xlabel(normal_axes(end),'Time [s]'); linkaxes(normal_axes,'x');
applyGlobalXLim(normal_axes,global_xlim);

%% 3. Force estimation x/y/z: raw, bar, and contact-consistent force
force_ylim = {[-60 60],[-60 60],[-60 60]}; % [mN], {x,y,z}; use [] for auto
figure('Name','Force estimation overlay','Color','w','Position',[120 70 1350 850]);
force_axes = gobjects(3,1);
force_names = {'$\hat{f}_{\ell}$','$\bar{f}_{\ell}$','$\hat{f}_{c}$'};
force_styles = {':','--','-'};
for component = 1:3
    force_axes(component) = subplot(3,1,component); hold on;
    for file_index = 1:numel(records)
        force_set = cat(3,records(file_index).f_raw,records(file_index).f_bar,records(file_index).f_c);
        for method = 1:3
            plot(records(file_index).t,1e3*force_set(:,component,method), ...
                'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
                'LineStyle',force_styles{method},'LineWidth',1.7, ...
                'DisplayName',legendLabel(dataset_labels{file_index},force_names{method}));
        end
    end
    grid on; box on; ylabel(sprintf('f_%s [mN]',axis_names{component}));
    applyConfiguredYLim(force_axes(component),force_ylim{component});
    if component == 1
        title('Force Estimation');
        legend('Location','eastoutside','Interpreter','latex');
    end
end
xlabel(force_axes(end),'Time [s]'); linkaxes(force_axes,'x');
applyGlobalXLim(force_axes,global_xlim);

%% 4. Normalized force estimation x/y/z versus true surface normal
unit_force_ylim = {[-1.1 1.1],[-1.1 1.1],[-1.1 1.1],[0 90]}; % {x,y,z,error angle deg}; [] for auto
figure('Name','Normalized force vs true normal','Color','w','Position',[140 60 1350 850]);
unit_axes = gobjects(4,1);
for component = 1:3
    unit_axes(component) = subplot(4,1,component); hold on;
    % Draw every true-normal curve before any force direction.
    for file_index = 1:numel(records)
        plot(records(file_index).t,records(file_index).true_normal(:,component), ...
            'Color',[0.76 0.76 0.76],'LineStyle','-','LineWidth',3.0, ...
            'DisplayName',legendLabel(dataset_labels{file_index},'true normal'));
    end
    for file_index = 1:numel(records)
        force_set = cat(3,records(file_index).f_raw_unit, ...
            records(file_index).f_bar_unit,records(file_index).f_c_unit);
        for method = 1:3
            plot(records(file_index).t,force_set(:,component,method), ...
                'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
                'LineStyle',force_styles{method},'LineWidth',1.6, ...
                'DisplayName',legendLabel(dataset_labels{file_index},force_names{method}));
        end
    end
    grid on; box on;
    applyConfiguredYLim(unit_axes(component),unit_force_ylim{component});
    ylabel(sprintf('%s component [-]',axis_names{component}));
    if component == 1
        title('Normalized force directions');
        legend('Location','eastoutside','Interpreter','latex');
    end
end
unit_axes(4) = subplot(4,1,4); hold on;
for file_index = 1:numel(records)
    unit_set = cat(3,records(file_index).f_raw_unit, ...
        records(file_index).f_bar_unit,records(file_index).f_c_unit);
    for method = 1:3
        direction_error = angleBetweenRowsDeg(unit_set(:,:,method), ...
            records(file_index).true_normal);
        plot(records(file_index).t,direction_error, ...
            'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
            'LineStyle',force_styles{method},'LineWidth',1.7, ...
            'DisplayName',legendLabel(dataset_labels{file_index},force_names{method}));
    end
end
grid on; box on; ylabel('angle [deg]');
title('Angle between normalized force direction and true normal');
applyConfiguredYLim(unit_axes(4),unit_force_ylim{4});
legend('Location','eastoutside','Interpreter','latex');
xlabel(unit_axes(end),'Time [s]'); linkaxes(unit_axes,'x');
applyGlobalXLim(unit_axes,global_xlim);

%% 5. End-effector trajectory and estimated-normal arrows
trajectory_iso_time = [0 60];       % [s], left: isometric view
trajectory_xz_time_1 = [0 30];      % [s], middle: X-Z view
trajectory_xz_time_2 = [30 60];     % [s], right: X-Z view
trajectory_iso_arrow_period = 6.0;  % [s], isometric normal-arrow interval
trajectory_xz_arrow_period = 3.0;   % [s], X-Z normal-arrow interval
trajectory_arrow_length = 0.08;     % [m], displayed arrow length
surface_y_half_width = 0.20;        % [m], surface width = origin_y +/- 20 cm

figure('Name','End-effector trajectory and normal arrows','Color','w', ...
    'Position',[60 180 1700 560]);
trajectory_axes = gobjects(3,1);

% Left: 3-D isometric view and known surface.
trajectory_axes(1) = subplot(1,3,1); hold on;
surface_u = linspace(0,1,501).';
[surface_xz,~] = fiveSectionGeometry(surface_u,cfg);
surface_y = cfg.origin(2)+linspace(-surface_y_half_width,surface_y_half_width,31);
surface_x = repmat(surface_xz(:,1),1,numel(surface_y));
surface_z = repmat(surface_xz(:,2),1,numel(surface_y));
surface_y_mesh = repmat(surface_y,size(surface_xz,1),1);
surf(trajectory_axes(1),surface_x,surface_y_mesh,surface_z, ...
    'FaceColor',[0.45 0.86 0.82],'FaceAlpha',0.34, ...
    'EdgeColor',[0.60 0.82 0.86],'EdgeAlpha',0.10, ...
    'FaceLighting','gouraud','AmbientStrength',0.55, ...
    'DiffuseStrength',0.75,'SpecularStrength',0.22,'SpecularExponent',18, ...
    'DisplayName','reference surface');
for file_index = 1:numel(records)
    selected = timeMask(records(file_index).t,trajectory_iso_time);
    plot3(records(file_index).ee_pos(selected,1),records(file_index).ee_pos(selected,2), ...
        records(file_index).ee_pos(selected,3),'LineWidth',3.2, ...
        'Color',[0.42 0.42 0.42],'DisplayName', ...
        legendLabel(dataset_labels{file_index},'end-effector trajectory'));
    trajectory_normals = cat(3,records(file_index).n_velocity_on_fraw, ...
        records(file_index).n_velocity_on_fbar,records(file_index).n_firmware, ...
        records(file_index).n_velocity_off_fhatc);
    for method = 1:numel(method_names)
        normal_data = trajectory_normals(:,:,method);
        arrows = timeSpacedIndices(records(file_index).t,selected& ...
            all(isfinite(records(file_index).ee_pos),2)& ...
            all(isfinite(normal_data),2),trajectory_iso_arrow_period);
        quiver3(records(file_index).ee_pos(arrows,1),records(file_index).ee_pos(arrows,2), ...
            records(file_index).ee_pos(arrows,3), ...
            trajectory_arrow_length*normal_data(arrows,1), ...
            trajectory_arrow_length*normal_data(arrows,2), ...
            trajectory_arrow_length*normal_data(arrows,3),0, ...
            'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
            'LineStyle',method_styles{method},'LineWidth',2.2,'MaxHeadSize',0.9, ...
            'DisplayName',legendLabel(dataset_labels{file_index},method_names{method}));
    end
end
grid on; box on; axis equal; view(-42,24);
camlight(trajectory_axes(1),'headlight'); material(trajectory_axes(1),'dull');
xlabel('x [m]'); ylabel('y [m]'); zlabel('z [m]');
title('Isometric view: 0-60 s'); legend('Location','best','Interpreter','latex');

% Middle/right: X-Z projections for the requested time intervals.
xz_windows = {trajectory_xz_time_1,trajectory_xz_time_2};
for panel = 1:2
    trajectory_axes(panel+1) = subplot(1,3,panel+1); hold on;
    plot(surface_xz(:,1),surface_xz(:,2),'Color',[0.45 0.82 0.84], ...
        'LineWidth',6.0,'DisplayName','reference surface');
    for file_index = 1:numel(records)
        selected = timeMask(records(file_index).t,xz_windows{panel});
        plot(records(file_index).ee_pos(selected,1),records(file_index).ee_pos(selected,3), ...
            'LineWidth',3.2,'Color',[0.58 0.58 0.58], ...
            'DisplayName',legendLabel(dataset_labels{file_index},'end-effector trajectory'));
        trajectory_normals = cat(3,records(file_index).n_velocity_on_fraw, ...
            records(file_index).n_velocity_on_fbar,records(file_index).n_firmware, ...
            records(file_index).n_velocity_off_fhatc);
        for method = 1:numel(method_names)
            normal_data = trajectory_normals(:,:,method);
            arrows = timeSpacedIndices(records(file_index).t,selected& ...
                all(isfinite(records(file_index).ee_pos),2)& ...
                all(isfinite(normal_data),2),trajectory_xz_arrow_period);
            quiver(records(file_index).ee_pos(arrows,1),records(file_index).ee_pos(arrows,3), ...
                trajectory_arrow_length*normal_data(arrows,1), ...
                trajectory_arrow_length*normal_data(arrows,3),0, ...
                'Color',curveColor(record_colors(file_index,:),method,numel(records)), ...
                'LineStyle',method_styles{method},'LineWidth',2.2,'MaxHeadSize',0.9, ...
                'DisplayName',legendLabel(dataset_labels{file_index},method_names{method}));
        end
    end
    grid on; box on; axis equal;
    xlabel('x [m]'); ylabel('z [m]');
    title(sprintf('X-Z view: %.0f-%.0f s',xz_windows{panel}));
    legend('Location','best','Interpreter','latex');
end

%% Local functions
function record = prepareRecord(T,file_name,cfg)
t = safeColumn(T,'t_sec');
if all(~isfinite(t)), t = (0:height(T)-1).'; end
first_finite = find(isfinite(t),1);
if ~isempty(first_finite), t = t-t(first_finite); end
vc = columnsXYZ(T,'fp_normal_vc');
t1 = columnsXYZ(T,'fp_normal_t1');
t2 = columnsXYZ(T,'fp_normal_t2');
f_c = columnsXYZ(T,'fp_normal_fcHat');
f_bar = columnsXYZ(T,'fp_normal_fBar');
f_raw = columnsXYZ(T,'fp_normal_fRaw');
ee_pos = columnsXYZ(T,'fp_normal_eePos');

record.label = erase(file_name,'.csv');
record.t = t;
record.f_c = f_c;
record.f_bar = f_bar;
record.f_raw = f_raw;
record.ee_pos = ee_pos;
record.u1_des = safeColumn(T,'u1_des');
record.u2_des = safeColumn(T,'u2_des');
record.v_t1 = sum(vc.*t1,2);
record.v_t2 = sum(vc.*t2,2);
record.force_desired = safeColumn(T,'forceDesired');
record.fn_hat = safeColumn(T,'fp_normal_fnHat');
record.n_firmware = columnsXYZ(T,'fp_normal_nHat');
record.n_velocity_on_fbar = offlineNormalEstimator(t,vc,f_bar,cfg,true);
record.n_velocity_on_fraw = offlineNormalEstimator(t,vc,f_raw,cfg,true);
record.n_velocity_off_fhatc = offlineNormalEstimator(t,vc,f_c,cfg,false);
record.f_c_unit = normalizeRows(f_c,1e-12);
record.f_bar_unit = normalizeRows(f_bar,1e-12);
record.f_raw_unit = normalizeRows(f_raw,1e-12);
[record.geometry_cfg,record.geometry_rms,record.surface_loop_time] = ...
    fitFiveSectionPose(t,ee_pos,cfg);
[record.true_normal,record.surface_section,record.surface_arc,record.surface_distance, ...
    record.surface_bounds] = trueNormalFromKnownGeometry(ee_pos,record.geometry_cfg,0.04);
middlePlaneMid=0.5*(record.surface_bounds(3)+record.surface_bounds(4));
upperCurveMid=0.5*(record.surface_bounds(4)+record.surface_bounds(5));
record.friction_plane_mask=record.surface_distance<=0.04 & ...
    record.surface_arc>=middlePlaneMid-0.10&record.surface_arc<=middlePlaneMid;
record.friction_curve_mask=record.surface_distance<=0.04 & ...
    record.surface_arc>=upperCurveMid&record.surface_arc<=record.surface_bounds(5);
record.friction_mask=record.friction_plane_mask|record.friction_curve_mask;
fprintf('  %s | surface RMS=%.2f mm, closed sweep=%.2f-%.2f s\n', ...
    record.label,1e3*record.geometry_rms,record.surface_loop_time);
end

function n_history = offlineNormalEstimator(t,velocity,force,cfg,use_qg)
% Offline directional-memory normal estimator. The normal-rate update is
% intentionally not velocity-gated; velocity is used only for optional q_g.
n_samples = numel(t); n_history = nan(n_samples,3);
L = zeros(3); n = nan(3,1); initialized = false;
for sample = 1:n_samples
    if ~all(isfinite([velocity(sample,:) force(sample,:)])), continue; end
    force_norm = norm(force(sample,:));
    if force_norm <= cfg.eps_f, continue; end
    qf = force(sample,:).'/force_norm;
    v = velocity(sample,:).'; v2 = dot(v,v);
    if use_qg && cfg.eps_v > 0
        q = qf-v*(dot(v,qf)/(v2+cfg.eps_v));
    else
        q = qf;
    end
    q_norm = norm(q);
    if ~isfinite(q_norm) || q_norm <= 1e-6, continue; end
    q = q/q_norm;
    if sample == 1, dt = 0.01; else, dt = t(sample)-t(sample-1); end
    if ~isfinite(dt) || dt <= 0, dt = 0.01; end
    % Firmware task runs at 100 Hz; split larger logger intervals accordingly.
    steps = max(1,ceil(dt/0.01)); sub_dt = dt/steps;
    for substep = 1:steps
        L = L+sub_dt*(-cfg.beta*L+cfg.beta*(q*q.'));
        if ~initialized
            n = q; initialized = true;
        else
            Ln = L*n;
            n_dot = cfg.gamma*(Ln-n*dot(n,Ln));
            n_next = n+sub_dt*n_dot;
            if norm(n_next) > 1e-6, n = n_next/norm(n_next); else, n = q; end
        end
    end
    if dot(n,force(sample,:).') < 0, n = -n; end
    n_history(sample,:) = n.';
end
end

function [fittedCfg,rmsError,loopTime] = fitFiveSectionPose(t,eePos,cfg)
% Fit only the X-Z translation of the already calibrated five-section shape.
% The longest closed out-and-back surface sweep is detected geometrically,
% so approach/departure tails cannot pull the fit away from the surface.
valid=isfinite(t)&all(isfinite(eePos(:,[1 3])),2);
validIdx=find(valid); pointsAll=eePos(validIdx,[1 3]);
[loopStart,loopEnd]=longestClosedLoop(pointsAll,0.035,1.0);
loopIdx=validIdx(loopStart:loopEnd); loopPoints=eePos(loopIdx,[1 3]);

% Spatial binning prevents slow sections and dwell time from dominating.
zEdges=linspace(min(loopPoints(:,2)),max(loopPoints(:,2)),101);
fitPoints=zeros(0,2);
for bin=1:numel(zEdges)-1
    selected=loopPoints(:,2)>=zEdges(bin)&loopPoints(:,2)<zEdges(bin+1);
    if bin==numel(zEdges)-1, selected=selected|loopPoints(:,2)==zEdges(end); end
    if any(selected), fitPoints(end+1,:)=median(loopPoints(selected,:),1); end %#ok<AGROW>
end
localCfg=cfg; localCfg.origin([1 3])=[0 0];
[localCenterline,~]=fiveSectionGeometry(linspace(0,1,2001).',localCfg);
originGuess=median(fitPoints-localCenterline( ...
    round(linspace(1,size(localCenterline,1),size(fitPoints,1))),:),1);
cost=@(origin)mean(min(pairwiseDistance2D(fitPoints,localCenterline+origin),[],2).^2);
originXZ=fminsearch(cost,originGuess,optimset('Display','off','TolX',1e-10,'TolFun',1e-12));
fittedCfg=cfg; fittedCfg.origin=[originXZ(1),median(eePos(loopIdx,2)),originXZ(2)];
distances=min(pairwiseDistance2D(fitPoints,localCenterline+originXZ),[],2);
rmsError=sqrt(mean(distances.^2)); loopTime=[t(loopIdx(1)) t(loopIdx(end))];
end

function [bestStart,bestEnd] = longestClosedLoop(points,closureTolerance,minLoopLength)
s=[0;cumsum(vecnorm(diff(points,1,1),2,2))];
bestStart=1; bestEnd=size(points,1); bestLength=-inf;
stride=max(1,floor(size(points,1)/1200));
for startIndex=1:stride:size(points,1)
    eligible=find(s-s(startIndex)>=minLoopLength & ...
        vecnorm(points-points(startIndex,:),2,2)<=closureTolerance);
    if isempty(eligible), continue; end
    [candidateLength,which]=max(s(eligible)-s(startIndex));
    if candidateLength>bestLength
        bestLength=candidateLength; bestStart=startIndex; bestEnd=eligible(which);
    end
end
if bestLength<minLoopLength
    warning('No closed surface sweep detected; using all finite EE samples.');
    bestStart=1; bestEnd=size(points,1);
end
end

function distance=pairwiseDistance2D(a,b)
delta=reshape(a,[],1,2)-reshape(b,1,[],2);
distance=sqrt(sum(delta.^2,3));
end

function [true_normal,section_id,arc_position,surface_distance,bounds] = ...
    trueNormalFromKnownGeometry(ee_pos,cfg,max_distance)
u = linspace(0,1,2001).';
[centerline,theta] = fiveSectionGeometry(u,cfg);
normal_dense = [-sin(theta),zeros(size(theta)),cos(theta)];
true_normal = nan(size(ee_pos));
section_id=nan(size(ee_pos,1),1); arc_position=nan(size(ee_pos,1),1);
surface_distance=nan(size(ee_pos,1),1);
turns=abs(deg2rad(cfg.turn_angles_deg));
lengths=[cfg.plane_lengths(1),cfg.curve_radius*turns(1),cfg.plane_lengths(2), ...
    cfg.curve_radius*turns(2),cfg.plane_lengths(3)];
bounds=[0 cumsum(lengths)]; denseArc=u*bounds(end);
for sample = 1:size(ee_pos,1)
    if ~all(isfinite(ee_pos(sample,[1 3]))), continue; end
    [distance_squared,nearest] = min(sum((centerline-ee_pos(sample,[1 3])).^2,2));
    surface_distance(sample)=sqrt(distance_squared); arc_position(sample)=denseArc(nearest);
    section_id(sample)=find(arc_position(sample)<=bounds(2:end)+eps,1,'first');
    if sqrt(distance_squared)<=max_distance
        true_normal(sample,:) = normal_dense(nearest,:);
    end
end
end

function [points,theta_out] = fiveSectionGeometry(u,cfg)
theta = deg2rad(cfg.initial_tangent_deg);
turns = -abs(deg2rad(cfg.turn_angles_deg)); radius = cfg.curve_radius;
plane_lengths = cfg.plane_lengths;
lengths = [plane_lengths(1) radius*abs(turns(1)) plane_lengths(2) ...
    radius*abs(turns(2)) plane_lengths(3)];
bounds = [0 cumsum(lengths)]; s = u*bounds(end);
points = nan(numel(u),2); theta_out = nan(numel(u),1);
position = cfg.origin([1 3]);
for segment = 1:5
    if segment < 5, selected = s>=bounds(segment)&s<bounds(segment+1); ...
    else, selected = s>=bounds(segment)&s<=bounds(segment+1)+eps; end
    local_s = s(selected)-bounds(segment);
    if mod(segment,2)==1
        points(selected,:) = position+local_s.*[cos(theta) sin(theta)];
        theta_out(selected) = theta;
        position = position+plane_lengths((segment+1)/2)*[cos(theta) sin(theta)];
    else
        turn = turns(segment/2);
        curvature = sign(turn)/radius; local_turn = curvature*local_s;
        points(selected,1) = position(1)+(sin(theta+local_turn)-sin(theta))/curvature;
        points(selected,2) = position(2)+(-cos(theta+local_turn)+cos(theta))/curvature;
        theta_out(selected) = theta+local_turn;
        position = position+[(sin(theta+turn)-sin(theta))/curvature, ...
            (-cos(theta+turn)+cos(theta))/curvature];
        theta = theta+turn;
    end
end
end

function x = safeColumn(T,name)
variables = string(T.Properties.VariableNames);
index = find(strcmpi(variables,string(name)),1);
if isempty(index), x = nan(height(T),1); else, x = double(T{:,index}); end
x = x(:);
end

function xyz = columnsXYZ(T,prefix)
xyz = [safeColumn(T,string(prefix)+'X'),safeColumn(T,string(prefix)+'Y'), ...
    safeColumn(T,string(prefix)+'Z')];
end

function unit = normalizeRows(x,threshold)
magnitude = vecnorm(x,2,2); unit = nan(size(x));
valid = all(isfinite(x),2)&isfinite(magnitude)&magnitude>threshold;
unit(valid,:) = x(valid,:)./magnitude(valid);
end

function color = curveColor(base,method,record_count)
if record_count == 1
    % With one CSV, distinguish curve meanings using clearly different hues.
    palette = lines(7);
    color = palette(method,:);
else
    % With overlays, preserve each CSV's identity and vary its shade by method.
    mix = [0.00 0.18 0.35 0.52 0.68];
    color = (1-mix(method))*base+mix(method)*[0.15 0.15 0.15];
end
end

function applyGlobalXLim(axes_handles,limits)
if isempty(limits), return; end
validateattributes(limits,{'numeric'},{'vector','numel',2,'finite','increasing'}, ...
    mfilename,'global_xlim');
set(axes_handles,'XLim',limits);
end

function applyConfiguredYLim(axis_handle,limits)
if isempty(limits), return; end
validateattributes(limits,{'numeric'},{'vector','numel',2,'finite','increasing'}, ...
    mfilename,'section_ylim');
ylim(axis_handle,limits);
end

function angle_deg = angleBetweenRowsDeg(a,b)
% Included angle acos((a dot b)/(|a||b|)), reported in degrees.
a_norm = vecnorm(a,2,2);
b_norm = vecnorm(b,2,2);
cosine = sum(a.*b,2)./(a_norm.*b_norm);
valid = all(isfinite(a),2)&all(isfinite(b),2)&a_norm>1e-12&b_norm>1e-12;
cosine = min(1,max(-1,cosine));
angle_deg = nan(size(cosine));
angle_deg(valid) = acosd(cosine(valid));
end

function label = extractWindLabel(file_label)
token = regexp(file_label,'(?i)wind(?:X|90|45|0)','match','once');
if isempty(token)
    label = file_label;
else
    suffix = extractAfter(string(token),4);
    label = char("wind"+suffix);
end
end

function label = legendLabel(dataset_label,curve_label)
if isempty(dataset_label)
    label = curve_label;
else
    label = sprintf('%s | %s',dataset_label,curve_label);
end
end

function selected = timeMask(t,time_window)
selected = isfinite(t)&t>=time_window(1)&t<=time_window(2);
end

function indices = timeSpacedIndices(t,valid,period)
candidates = find(valid(:)&isfinite(t(:)));
indices = zeros(0,1);
next_time = -inf;
for candidate_number = 1:numel(candidates)
    candidate = candidates(candidate_number);
    if t(candidate) >= next_time
        indices(end+1,1) = candidate; %#ok<AGROW>
        next_time = t(candidate)+period;
    end
end
end

function folder=activeScriptDirectory()
folder='';
stack=dbstack('-completenames');
for k=1:numel(stack)
    if endsWith(string(stack(k).file),'data_1st_exp_overlay.m')
        folder=fileparts(stack(k).file); break;
    end
end
try
    activeFile=matlab.desktop.editor.getActiveFilename;
    if isempty(folder)&&~isempty(activeFile)&&endsWith(string(activeFile),'.m','IgnoreCase',true)
        folder=fileparts(activeFile);
    end
catch
end
if isempty(folder), folder=fileparts(mfilename('fullpath')); end
if isempty(folder), folder=pwd; end
end
