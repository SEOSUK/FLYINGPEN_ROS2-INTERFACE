%% Second-experiment path-aligned overlay analysis
% Multiple runs are aligned by normalized XY arc length, not by time.
clear; close all; clc;

%% User settings
path_xlim=[0 99];                    % normalized fitted-loop progress [%]
time_xlim=[0 97.5];                     % [s], time-aligned overview
geometry_fit_xlim=[0 98];
geometry_large_radius=0.420; geometry_small_radius=0.280;
geometry_plane_length_guess=1.0;
trajectory_contact_end_time=76.0;     % [s], alpha-OFF trajectory leaves the surface
alpha_off_first_low_curvature_delay=2.0; % [s], delay first gentle-curve interval
align_path_by_ground_truth=true;       % use ON run's full path length as common scale
alpha_off_path_shift=3.5;              % [% point], positive shifts OFF to the right
normal_arrow_path_period=2.5;         % arrow spacing [% path]
normal_arrow_length=0.10;             % [m]
a_bar_n=0.005; small=1.0e-8;

%% Portable multi-file loading
dataDir=activeScriptDirectory();
[selectedFiles,selectedPath]=uigetfile( ...
    {'alpha*.csv','Normal-estimator CSV files (*.csv)';'*.csv','All CSV files'}, ...
    'Select second-experiment CSV files',dataDir,'MultiSelect','on');
if isequal(selectedFiles,0), return; end
if ischar(selectedFiles)||isstring(selectedFiles), selectedFiles=cellstr(selectedFiles); end
selectedFiles=sort(selectedFiles);

records=struct([]);
for fileIndex=1:numel(selectedFiles)
    csvFile=fullfile(selectedPath,selectedFiles{fileIndex});
    fprintf('Loading %s\n',csvFile);
    T=readtable(csvFile,detectImportOptions(csvFile,'Delimiter',','));
    r=prepareRecord(T,selectedFiles{fileIndex},geometry_fit_xlim, ...
        geometry_small_radius,geometry_large_radius,geometry_plane_length_guess, ...
        trajectory_contact_end_time,alpha_off_first_low_curvature_delay,a_bar_n,small);
    if fileIndex==1, records=r; else, records(fileIndex)=r; end
    fprintf(['  %s | path length %.3f m | lap boundary %.1f%% | fit RMS %.2f mm | ' ...
        'loop %.2f-%.2f s\n'],r.label,r.pathLength,r.lapBoundaryPercent, ...
        1e3*r.geometry.rms,r.geometry.loopTime);
end
if align_path_by_ground_truth
    records=alignPathByReferenceDistance(records,alpha_off_path_shift);
    fprintf('Path progress uses fitted two-lap ON reference length.\n');
end
overlayPalette=[0.85 0.33 0.10; 0.49 0.18 0.56; 0.47 0.67 0.19; ...
                0.93 0.69 0.13; 0.30 0.75 0.93; 0.64 0.08 0.18];
colors=overlayPalette(mod(0:numel(records)-1,size(overlayPalette,1))+1,:);
labels=cellfun(@experimentLabel,{records.label},'UniformOutput',false);

%% 0. Path-aligned overview panel
path_figure_position=[80 50 1400 750]; % [left bottom width height] [px]

plotOverviewPanel(records,labels,colors,path_xlim,path_figure_position, ...
    normal_arrow_path_period,normal_arrow_length,'path', ...
    geometry_small_radius,geometry_large_radius);

%% 1. Time-aligned overview panel
time_figure_position=[80 50 1400 750]; % [left bottom width height] [px]

plotOverviewPanel(records,labels,colors,time_xlim,time_figure_position, ...
    1.0,normal_arrow_length,'time',geometry_small_radius,geometry_large_radius);

%% Local functions
function plotOverviewPanel(records,labels,colors,xLimits,figurePosition,arrowPeriod,arrowLength, ...
    alignmentMode,smallRadius,largeRadius)
fig=figure('Name',sprintf('2nd experiment: %s-aligned overview',alignmentMode),'Color','w', ...
    'Position',figurePosition);
panelPositions=[0.015 0.515 0.477 0.475; 0.015 0.015 0.477 0.475; ...
                0.508 0.515 0.477 0.475; 0.508 0.015 0.477 0.475];
panels=gobjects(4,1);
for k=1:4
    panels(k)=uipanel(fig,'Units','normalized','Position',panelPositions(k,:), ...
        'BackgroundColor','w','BorderType','line');
end

% Top left: physical XY trajectories and path-spaced estimated normals.
ax=axes(panels(1)); hold(ax,'on');
for k=1:numel(records)
    r=records(k); c=colors(k,:); coordinate=alignmentCoordinate(r,alignmentMode);
    valid=isfinite(coordinate)&coordinate>=xLimits(1)&coordinate<=xLimits(2)& ...
        all(isfinite(r.eePos(:,1:2)),2);
    trajectoryValid=valid;
    if strcmp(alignmentMode,'path')
        trajectoryValid=isfinite(r.t)&r.t>=r.geometry.loopTime(1)& ...
            all(isfinite(r.eePos(:,1:2)),2);
    end
    plot(ax,r.eePos(trajectoryValid,2),r.eePos(trajectoryValid,1), ...
        'Color',lightenColor(c,0.72), ...
        'LineWidth',1.5, ...
        'DisplayName',labels{k});
    [highCurvature,lowCurvature]=curvatureMasks(r.trueCurvature,smallRadius,largeRadius);
    plotMaskedTrajectory(ax,r.eePos(:,2),r.eePos(:,1),valid&highCurvature,[0.95 0.48 0.14]);
    plotMaskedTrajectory(ax,r.eePos(:,2),r.eePos(:,1),valid&lowCurvature,[0.55 0.42 0.78]);
    arrows=pathSpacedIndices(coordinate,valid&isfinite(r.trueCurvature)& ...
        all(isfinite(r.nHat(:,1:2)),2),arrowPeriod);
    quiver(ax,r.eePos(arrows,2),r.eePos(arrows,1),arrowLength*r.nHat(arrows,2), ...
        arrowLength*r.nHat(arrows,1),0,'Color',c,'LineWidth',1.3, ...
        'MaxHeadSize',0.7,'HandleVisibility','off');
end
plot(ax,nan,nan,'Color',[0.95 0.48 0.14],'LineWidth',4.0,'DisplayName','high curvature');
plot(ax,nan,nan,'Color',[0.55 0.42 0.78],'LineWidth',4.0,'DisplayName','low curvature');
axis(ax,'equal'); grid(ax,'on'); box(ax,'on'); xlabel(ax,'EE y [m]'); ylabel(ax,'EE x [m]');
title(ax,'XY Trajectory and Estimated Normal'); showRecordLegend(ax,numel(records));
xlim(ax,[-1 1]); ylim(ax,[0 1.2]);

% Bottom left: true/estimated normal components.
layout=tiledlayout(panels(2),3,1,'TileSpacing','compact','Padding','compact');
normalAxes=gobjects(3,1); componentNames={'x','y','z'};
for component=1:3
    normalAxes(component)=nexttile(layout); hold(normalAxes(component),'on');
    for k=1:numel(records)
        r=records(k); c=colors(k,:); coordinate=alignmentCoordinate(r,alignmentMode);
        trueNormal=alignedTrueNormal(r,alignmentMode);
        plot(normalAxes(component),coordinate,trueNormal(:,component),'--', ...
            'Color',[0.76 0.76 0.76],'LineWidth',3.0,'HandleVisibility','off');
        plot(normalAxes(component),coordinate,r.nHat(:,component),'-', ...
            'Color',c,'LineWidth',1.7,'DisplayName',labels{k});
    end
    grid(normalAxes(component),'on'); box(normalAxes(component),'on');
    ylabel(normalAxes(component),sprintf('n_%s [-]',componentNames{component}));
    ylim(normalAxes(component),[-1 1]);
end
title(normalAxes(1),'Normal Vector');
showRecordLegend(normalAxes(1),numel(records));
finishAlignedAxes(normalAxes,xLimits,alignmentMode);
addCurvatureShading(normalAxes,records(1),alignmentMode,smallRadius,largeRadius);

% Top right: estimated normal-rate components.
layout=tiledlayout(panels(3),3,1,'TileSpacing','compact','Padding','compact');
rateAxes=gobjects(3,1);
for component=1:3
    rateAxes(component)=nexttile(layout); hold(rateAxes(component),'on');
    for k=1:numel(records)
        coordinate=alignmentCoordinate(records(k),alignmentMode);
        plot(rateAxes(component),coordinate,records(k).nDotFiltered(:,component), ...
            'Color',colors(k,:),'LineWidth',1.7,'DisplayName',labels{k});
    end
    grid(rateAxes(component),'on'); box(rateAxes(component),'on');
    ylabel(rateAxes(component),sprintf('dn_%s/dt [1/s]',componentNames{component}));
    ylim(rateAxes(component),[-0.6 0.6]);
end
title(rateAxes(1),'Estimated Normal Rate');
showRecordLegend(rateAxes(1),numel(records));
finishAlignedAxes(rateAxes,xLimits,alignmentMode);
addCurvatureShading(rateAxes,records(1),alignmentMode,smallRadius,largeRadius);

% Bottom right: force, curvature, modulation, and velocity.
layout=tiledlayout(panels(4),4,1,'TileSpacing','compact','Padding','compact');
metricAxes=gobjects(4,1);
for j=1:4, metricAxes(j)=nexttile(layout); hold(metricAxes(j),'on'); end
for k=1:numel(records)
    r=records(k); c=colors(k,:); coordinate=alignmentCoordinate(r,alignmentMode);
    plot(metricAxes(1),coordinate,1e3*r.forceDesired,'--','Color',c, ...
        'LineWidth',2.6,'DisplayName',labels{k});
    plot(metricAxes(1),coordinate,1e3*r.fnHat,'Color',lightenColor(c,0.58), ...
        'LineWidth',1.5,'HandleVisibility','off');
    trueCurvature=alignedTrueCurvature(r,alignmentMode);
    plot(metricAxes(2),coordinate,trueCurvature,'--','Color',[0.76 0.76 0.76], ...
        'LineWidth',3.0,'HandleVisibility','off');
    plot(metricAxes(2),coordinate,r.kappaHatFiltered,'Color',lightenColor(c,0.42), ...
        'LineWidth',1.6,'DisplayName',labels{k});
    plot(metricAxes(3),coordinate,r.alphaStarFiltered,'Color',c,'LineWidth',1.8,'DisplayName',labels{k});
    plot(metricAxes(4),coordinate,r.initialT1Cmd,'-','Color',[0.35 0.35 0.35], ...
        'LineWidth',2.3,'HandleVisibility','off');
    if ~isAlphaOff(r.label)
        plot(metricAxes(4),coordinate,r.finalT1Cmd,'-','Color',[0.85 0.12 0.10], ...
            'LineWidth',2.0,'HandleVisibility','off');
    end
    plot(metricAxes(4),coordinate,r.measuredT1Velocity,':', ...
        'Color',lightenColor(c,0.68),'LineWidth',1.6, ...
        'DisplayName',labels{k});
end
ylabel(metricAxes(1),'F_n [mN]'); title(metricAxes(1),'Normal Force');
ylabel(metricAxes(2),'curvature [1/m]'); title(metricAxes(2),'Curvature Estimate');
ylabel(metricAxes(3),'\alpha^* [-]'); title(metricAxes(3),'Velocity Modulation');
ylabel(metricAxes(4),'v_{t1} [m/s]');
title(metricAxes(4),'t1-frame Velocity');
ylim(metricAxes(1),[0 40]); ylim(metricAxes(2),[0 5]);
ylim(metricAxes(3),[0 1]); ylim(metricAxes(4),[0 0.2]);
for j=1:4, grid(metricAxes(j),'on'); box(metricAxes(j),'on'); end
showRecordLegend(metricAxes(1),numel(records));
finishAlignedAxes(metricAxes,xLimits,alignmentMode);
addCurvatureShading(metricAxes,records(1),alignmentMode,smallRadius,largeRadius);
plotErrorWindow(records,labels,colors,xLimits,figurePosition,alignmentMode);
end

function plotErrorWindow(records,labels,colors,xLimits,overviewPosition,alignmentMode)
errorPosition=[overviewPosition(1)+80 overviewPosition(2)+80 850 560];
figure('Name',sprintf('2nd experiment: %s-aligned errors',alignmentMode), ...
    'Color','w','Position',errorPosition);
layout=tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
ax=gobjects(2,1);
for panel=1:2, ax(panel)=nexttile(layout); hold(ax(panel),'on'); end
for k=1:numel(records)
    r=records(k); coordinate=alignmentCoordinate(r,alignmentMode);
    trueNormal=alignedTrueNormal(r,alignmentMode);
    normalAngularError=normalAngleErrorDeg(trueNormal,r.nHat);
    forceControlError=1e3*abs(r.fnHat-r.forceDesired);
    plot(ax(1),coordinate,normalAngularError,'Color',colors(k,:), ...
        'LineWidth',1.8,'DisplayName',labels{k});
    plot(ax(2),coordinate,forceControlError,'Color',colors(k,:), ...
        'LineWidth',1.8,'DisplayName',labels{k});
end
grid(ax(1),'on'); box(ax(1),'on'); ylabel(ax(1),'angle [deg]');
title(ax(1),'Normal Estimation Angular Error');
grid(ax(2),'on'); box(ax(2),'on'); ylabel(ax(2),'|F_n-F_{n,cmd}| [mN]');
title(ax(2),'Force Control Error Norm');
showRecordLegend(ax(1),numel(records));
finishAlignedAxes(ax,xLimits,alignmentMode);
end

function errorDeg=normalAngleErrorDeg(reference,estimate)
referenceNorm=vecnorm(reference,2,2); estimateNorm=vecnorm(estimate,2,2);
cosine=sum(reference.*estimate,2)./(referenceNorm.*estimateNorm);
valid=all(isfinite(reference),2)&all(isfinite(estimate),2)& ...
    referenceNorm>1e-12&estimateNorm>1e-12;
cosine=min(1,max(-1,cosine)); errorDeg=nan(size(cosine));
errorDeg(valid)=acosd(cosine(valid));
end

function finishAlignedAxes(ax,xLimits,alignmentMode)
if strcmp(alignmentMode,'path'), xText='Path progress [%]'; else, xText='Time [s]'; end
xlabel(ax(end),xText); set(ax(1:end-1),'XTickLabel',[]);
linkaxes(ax,'x'); set(ax,'XLim',xLimits);
end

function r=prepareRecord(T,label,fitWindow,smallRadius,largeRadius,planeLength, ...
    contactEndTime,alphaOffLowDelay,aBarN,small)
r.label=label; r.t=safeColumn(T,"t_sec");
if all(~isfinite(r.t)), r.t=(0:height(T)-1).'; end
first=find(isfinite(r.t),1); if ~isempty(first), r.t=r.t-r.t(first); end
r.eePos=columnsXYZ(T,"fp_normal_eePos"); r.vc=columnsXYZ(T,"fp_normal_vc");
r.t1=columnsXYZ(T,"fp_normal_t1");
r.fcHat=columnsXYZ(T,"fp_normal_fcHat"); r.nHat=columnsXYZ(T,"fp_normal_nHat");
r.nDot=columnsXYZ(T,"fp_normal_nDot"); r.kappaHat=safeColumn(T,"fp_normal_kappaHat");
u1=safeColumn(T,"u1_des"); u2=safeColumn(T,"u2_des");
r.forceDesired=safeColumn(T,"forceDesired"); r.fnHat=safeColumn(T,"fp_normal_fnHat");
denominator=abs(r.kappaHat).*hypot(u1,u2).^2; valid=isfinite(denominator)&denominator>small;
r.alphaGN=nan(height(T),1); r.alphaGN(valid)=sqrt(aBarN./denominator(valid));
r.alphaStar=min(1,r.alphaGN); r.alphaStar(~valid)=1;
r.nDotFiltered=zeroPhaseLowPass(r.nDot,r.t,1.0);
r.kappaHatFiltered=zeroPhaseLowPass(r.kappaHat,r.t,1.0);
r.alphaStarFiltered=zeroPhaseLowPass(r.alphaStar,r.t,1.0);
r.initialT1Cmd=u1; r.finalT1Cmd=r.alphaStar.*u1;
r.geometry=fitTwoCylinderSurface(r.t,r.eePos,fitWindow,smallRadius,largeRadius,planeLength);
r.trueNormal=r.geometry.trueNormal; r.trueCurvature=r.geometry.trueCurvature;
afterContact=isAlphaOff(label)&r.t>contactEndTime;
r.trueNormal(afterContact,:)=nan; r.trueCurvature(afterContact)=nan;
if isAlphaOff(label)&&alphaOffLowDelay>0
    lowMask=isfinite(r.trueCurvature)&abs(r.trueCurvature-1/largeRadius)<0.08;
    firstLowStart=find(lowMask&[true;~lowMask(1:end-1)],1);
    if ~isempty(firstLowStart)
        delayedPart=lowMask&r.t<r.t(firstLowStart)+alphaOffLowDelay;
        r.trueCurvature(delayedPart)=0;
    end
end
r.trueT1=[-r.trueNormal(:,2),r.trueNormal(:,1),zeros(height(T),1)];
opposite=sum(r.trueT1.*r.t1,2)<0; r.trueT1(opposite,:)=-r.trueT1(opposite,:);
r.measuredT1Velocity=sum(r.vc.*r.trueT1,2);
pathLoopTime=r.geometry.loopTime;
if isAlphaOff(label)
    % Continue the XY-distance coordinate after contact loss so post-loss
    % signals remain visible; ground truth itself is still cut at loss time.
    finiteTime=r.t(isfinite(r.t));
    if ~isempty(finiteTime), pathLoopTime(2)=max(finiteTime); end
end
[r.pathPercent,r.pathLength,r.lapBoundaryPercent]= ...
    normalizedLoopPath(r.t,r.eePos,pathLoopTime);
end

function [progress,totalLength,lapBoundary]=normalizedLoopPath(t,eePos,loopTime)
progress=nan(size(t)); valid=isfinite(t)&all(isfinite(eePos(:,1:2)),2)& ...
    t>=loopTime(1)&t<=loopTime(2); idx=find(valid); totalLength=0; lapBoundary=50;
if numel(idx)<2, return; end
s=[0;cumsum(vecnorm(diff(eePos(idx,1:2),1,1),2,2))]; totalLength=s(end);
if totalLength>eps
    progress(idx)=100*s/totalLength;
    % The first return to the starting XY point separates lap 1 and lap 2.
    candidates=find(s>=0.30*totalLength&s<=0.70*totalLength);
    if ~isempty(candidates)
        returnDistance=vecnorm(eePos(idx(candidates),1:2)-eePos(idx(1),1:2),2,2);
        [~,nearest]=min(returnDistance);
        lapBoundary=progress(idx(candidates(nearest)));
    end
end
end

function records=alignPathByReferenceDistance(records,alphaOffPathShift)
% A fitted surface lap is geometric and independent of the selected log.
% Two complete ON laps define 100%; an early OFF contact loss stays below 100%.
onIndex=find(~cellfun(@isAlphaOff,{records.label}),1);
if isempty(onIndex), geometryIndex=1; else, geometryIndex=onIndex; end
centerline=records(geometryIndex).geometry.centerline;
oneLapLength=sum(vecnorm(diff([centerline;centerline(1,:)],1,1),2,2));
referenceLength=2*oneLapLength;
if ~isfinite(referenceLength)||referenceLength<=eps, return; end
for recordIndex=1:numel(records)
    scale=records(recordIndex).pathLength/referenceLength;
    records(recordIndex).pathPercent=records(recordIndex).pathPercent*scale;
    records(recordIndex).lapBoundaryPercent=records(recordIndex).lapBoundaryPercent*scale;
end
if isempty(onIndex), referenceIndex=1; else, referenceIndex=onIndex; end
[referenceProgress,uniqueIndex]=unique(records(referenceIndex).pathPercent,'stable');
validReference=isfinite(referenceProgress)& ...
    all(isfinite(records(referenceIndex).trueNormal(uniqueIndex,:)),2)& ...
    isfinite(records(referenceIndex).trueCurvature(uniqueIndex));
referenceProgress=referenceProgress(validReference);
referenceNormal=records(referenceIndex).trueNormal(uniqueIndex(validReference),:);
referenceCurvature=records(referenceIndex).trueCurvature(uniqueIndex(validReference));
if ~isempty(onIndex)
    for recordIndex=1:numel(records)
        if ~isAlphaOff(records(recordIndex).label), continue; end
        [pathScale,pathShift]=bestTrueNormalAffine(referenceProgress,referenceNormal, ...
            records(recordIndex),alphaOffPathShift);
        records(recordIndex).pathPercent= ...
            pathScale*records(recordIndex).pathPercent+pathShift;
        records(recordIndex).lapBoundaryPercent= ...
            pathScale*records(recordIndex).lapBoundaryPercent+pathShift;
        fprintf('  %s | true-normal path alignment: scale %.5f, shift %+.3f%%\n', ...
            records(recordIndex).label,pathScale,pathShift);
    end
elseif isAlphaOff(records(1).label)
    % With OFF only, retain the user shift while keeping the two-lap scale.
    records(1).pathPercent=records(1).pathPercent+alphaOffPathShift;
    records(1).lapBoundaryPercent=records(1).lapBoundaryPercent+alphaOffPathShift;
end
for recordIndex=1:numel(records)
    query=records(recordIndex).pathPercent;
    records(recordIndex).alignedTrueNormal=nan(size(records(recordIndex).trueNormal));
    records(recordIndex).alignedTrueCurvature=nan(size(records(recordIndex).trueCurvature));
    inside=isfinite(query)&query>=referenceProgress(1)&query<=referenceProgress(end);
    records(recordIndex).alignedTrueNormal(inside,:)=interp1( ...
        referenceProgress,referenceNormal,query(inside),'linear');
    records(recordIndex).alignedTrueCurvature(inside)=interp1( ...
        referenceProgress,referenceCurvature,query(inside),'previous');
end
end

function [bestScale,bestShift]=bestTrueNormalAffine(referenceProgress,referenceNormal,target,shiftGuess)
valid=find(isfinite(target.pathPercent)&all(isfinite(target.trueNormal),2));
if numel(valid)<20, bestScale=1; bestShift=shiftGuess; return; end
valid=valid(round(linspace(1,numel(valid),min(700,numel(valid)))));
targetProgress=target.pathPercent(valid); targetNormal=target.trueNormal(valid,:);
targetNormal=targetNormal./max(vecnorm(targetNormal,2,2),eps);
referenceNormal=referenceNormal./max(vecnorm(referenceNormal,2,2),eps);
bestCost=inf; bestScale=1; bestShift=shiftGuess;
for scale=0.97:0.002:1.03
    for shift=shiftGuess-5:0.05:shiftGuess+5
        query=scale*targetProgress+shift;
        inside=query>=referenceProgress(1)&query<=referenceProgress(end);
        if sum(inside)<20, continue; end
        expected=interp1(referenceProgress,referenceNormal,query(inside),'linear');
        cosine=sum(expected.*targetNormal(inside,:),2)./max(vecnorm(expected,2,2),eps);
        cost=mean(1-min(1,max(-1,cosine)));
        if cost<bestCost, bestCost=cost; bestScale=scale; bestShift=shift; end
    end
end
end

function records=alignPathByGroundTruth(records)
% Align lap 1 and lap 2 independently using each run's detected return point.
reference=records(1);
referenceBounds=[0 reference.lapBoundaryPercent;reference.lapBoundaryPercent 100];
for recordIndex=2:numel(records)
    target=records(recordIndex);
    targetBounds=[0 target.lapBoundaryPercent;target.lapBoundaryPercent 100];
    for lap=1:2
        referenceLower=referenceBounds(lap,1); referenceUpper=referenceBounds(lap,2);
        targetLower=targetBounds(lap,1); targetUpper=targetBounds(lap,2);
        referenceValid=find(reference.pathPercent>=referenceLower&reference.pathPercent<=referenceUpper& ...
            all(isfinite(reference.trueNormal),2)&isfinite(reference.trueCurvature));
        targetValid=find(target.pathPercent>=targetLower&target.pathPercent<=targetUpper& ...
            all(isfinite(target.trueNormal),2)&isfinite(target.trueCurvature));
        if numel(referenceValid)<20||numel(targetValid)<20, continue; end
        referenceKnots=referenceValid(round(linspace(1,numel(referenceValid),min(240,numel(referenceValid)))));
        targetKnots=targetValid(round(linspace(1,numel(targetValid),min(240,numel(targetValid)))));
        referenceNormal=reference.trueNormal(referenceKnots,:);
        targetNormal=target.trueNormal(targetKnots,:);
        referenceNormal=referenceNormal./max(vecnorm(referenceNormal,2,2),eps);
        targetNormal=targetNormal./max(vecnorm(targetNormal,2,2),eps);
        referenceCurvature=reference.trueCurvature(referenceKnots);
        targetCurvature=target.trueCurvature(targetKnots);
        referenceProgress=reference.pathPercent(referenceKnots);
        targetProgress=target.pathPercent(targetKnots);
        normalCost=1-max(-1,min(1,referenceNormal*targetNormal.'));
        curvatureScale=max([referenceCurvature;targetCurvature;1]);
        curvatureCost=abs(referenceCurvature-targetCurvature.')/curvatureScale;
        referenceLocal=(referenceProgress-referenceLower)/(referenceUpper-referenceLower);
        targetLocal=(targetProgress-targetLower)/(targetUpper-targetLower);
        progressCost=abs(referenceLocal-targetLocal.');
        [referencePath,targetPath]=dynamicTimeWarpPath( ...
            normalCost+0.45*curvatureCost+0.35*progressCost);
        mappedProgress=nan(numel(targetKnots),1);
        for knot=1:numel(targetKnots)
            matches=referencePath(targetPath==knot);
            if ~isempty(matches), mappedProgress(knot)=mean(referenceProgress(matches)); end
        end
        validMap=isfinite(mappedProgress);
        [rawProgress,uniqueIndex]=unique(targetProgress(validMap),'stable');
        mappedProgress=mappedProgress(validMap); mappedProgress=mappedProgress(uniqueIndex);
        if numel(rawProgress)>=2
            inside=isfinite(target.pathPercent)&target.pathPercent>=targetLower& ...
                target.pathPercent<=targetUpper;
            aligned=interp1(rawProgress,mappedProgress,target.pathPercent(inside),'linear','extrap');
            records(recordIndex).pathPercent(inside)= ...
                min(referenceUpper,max(referenceLower,aligned));
        end
    end
end
end

function [rowPath,columnPath]=dynamicTimeWarpPath(cost)
[rowCount,columnCount]=size(cost); accumulated=inf(rowCount,columnCount);
predecessor=zeros(rowCount,columnCount,'uint8'); accumulated(1,1)=cost(1,1);
for row=1:rowCount
    for column=1:columnCount
        if row==1&&column==1, continue; end
        candidates=[inf inf inf]; % diagonal, vertical, horizontal
        if row>1&&column>1, candidates(1)=accumulated(row-1,column-1); end
        if row>1, candidates(2)=accumulated(row-1,column); end
        if column>1, candidates(3)=accumulated(row,column-1); end
        [best,step]=min(candidates);
        accumulated(row,column)=cost(row,column)+best; predecessor(row,column)=step;
    end
end
row=rowCount; column=columnCount; rowPath=row; columnPath=column;
while row>1||column>1
    step=predecessor(row,column);
    if step==1, row=row-1; column=column-1;
    elseif step==2, row=row-1;
    else, column=column-1;
    end
    rowPath(end+1,1)=row; columnPath(end+1,1)=column; %#ok<AGROW>
end
rowPath=flipud(rowPath); columnPath=flipud(columnPath);
end

function idx=pathSpacedIndices(path,valid,period)
candidates=find(valid&isfinite(path)); idx=zeros(0,1); nextPath=-inf;
for k=1:numel(candidates)
    candidate=candidates(k);
    if path(candidate)>=nextPath
        idx(end+1,1)=candidate; %#ok<AGROW>
        nextPath=path(candidate)+period;
    end
end
end

function [highMask,lowMask]=curvatureMasks(curvature,smallRadius,largeRadius)
highMask=isfinite(curvature)&abs(curvature-1/smallRadius)<0.08;
lowMask=isfinite(curvature)&abs(curvature-1/largeRadius)<0.08;
end

function plotMaskedTrajectory(ax,x,y,mask,color)
xMasked=x; yMasked=y; xMasked(~mask)=nan; yMasked(~mask)=nan;
plot(ax,xMasked,yMasked,'Color',color,'LineWidth',4.0,'HandleVisibility','off');
end

function addCurvatureShading(axesHandles,record,alignmentMode,smallRadius,largeRadius)
coordinate=alignmentCoordinate(record,alignmentMode);
[highMask,lowMask]=curvatureMasks(record.trueCurvature,smallRadius,largeRadius);
masks={highMask,lowMask}; regionColors={[0.95 0.48 0.14],[0.55 0.42 0.78]};
for axisNumber=1:numel(axesHandles)
    ax=axesHandles(axisNumber); yLimits=ylim(ax); holdWasOn=ishold(ax); hold(ax,'on');
    for curvatureType=1:2
        intervals=maskToIntervals(coordinate,masks{curvatureType});
        for intervalNumber=1:size(intervals,1)
            interval=intervals(intervalNumber,:);
            region=patch(ax,[interval(1) interval(2) interval(2) interval(1)], ...
                [yLimits(1) yLimits(1) yLimits(2) yLimits(2)],regionColors{curvatureType}, ...
                'FaceAlpha',0.12,'EdgeColor','none','HandleVisibility','off');
            uistack(region,'bottom');
        end
    end
    if ~holdWasOn, hold(ax,'off'); end
end
end

function intervals=maskToIntervals(coordinate,mask)
valid=mask(:)&isfinite(coordinate(:));
starts=find(valid&[true;~valid(1:end-1)]);
stops=find(valid&[~valid(2:end);true]);
intervals=[coordinate(starts) coordinate(stops)];
end

function coordinate=alignmentCoordinate(record,alignmentMode)
if strcmp(alignmentMode,'path'), coordinate=record.pathPercent; else, coordinate=record.t; end
end

function value=alignedTrueNormal(record,alignmentMode)
% Plot each log's independently fitted ground truth for alignment checks.
value=record.trueNormal;
end

function value=alignedTrueCurvature(record,alignmentMode)
% Plot each log's independently fitted ground truth for alignment checks.
value=record.trueCurvature;
end

function color=lightenColor(color,amount)
color=(1-amount)*color+amount*[1 1 1];
end

function tf=isAlphaOff(fileName)
tf=~isempty(regexpi(fileName,'alphaX','once'));
end

function filtered=zeroPhaseLowPass(data,t,cutoffHz)
% Forward/backward first-order RC low-pass for display without phase delay.
filtered=nan(size(data)); rc=1/(2*pi*cutoffHz);
for column=1:size(data,2)
    valid=isfinite(t)&isfinite(data(:,column));
    if sum(valid)<2, continue; end
    x=interp1(t(valid),data(valid,column),t,'linear','extrap');
    forward=x;
    for sample=2:numel(t)
        dt=t(sample)-t(sample-1);
        if ~isfinite(dt)||dt<=0, dt=0.01; end
        alpha=dt/(rc+dt);
        forward(sample)=forward(sample-1)+alpha*(x(sample)-forward(sample-1));
    end
    backward=forward;
    for sample=numel(t)-1:-1:1
        dt=t(sample+1)-t(sample);
        if ~isfinite(dt)||dt<=0, dt=0.01; end
        alpha=dt/(rc+dt);
        backward(sample)=backward(sample+1)+alpha*(forward(sample)-backward(sample+1));
    end
    backward(~valid)=nan; filtered(:,column)=backward;
end
end

function label=experimentLabel(fileName)
[~,rawLabel]=fileparts(fileName);
if ~isempty(regexpi(rawLabel,'alpha1t','once'))
    label='$\alpha^*$ ON';
elseif ~isempty(regexpi(rawLabel,'alphaX','once'))
    label='$\alpha^*$ OFF';
else
    label=regexprep(rawLabel,'_flyingpen_normal_.*$','');
    label=strrep(label,'_',' ');
end
end

function showRecordLegend(ax,recordCount)
if recordCount>1
    legend(ax,'Location','best','Interpreter','latex');
else
    legend(ax,'off');
end
end
function x=safeColumn(T,name)
vars=string(T.Properties.VariableNames); idx=find(strcmpi(vars,string(name)),1);
if isempty(idx), x=nan(height(T),1); else, x=double(T{:,idx}); end
x=x(:);
end
function xyz=columnsXYZ(T,prefix)
xyz=[safeColumn(T,string(prefix)+"X"),safeColumn(T,string(prefix)+"Y"),safeColumn(T,string(prefix)+"Z")];
end

function fit=fitTwoCylinderSurface(t,eePos,timeWindow,smallRadius,largeRadius,planeLengthGuess)
sampleValid=isfinite(t)&all(isfinite(eePos),2); fitValid=sampleValid;
if ~isempty(timeWindow), fitValid=fitValid&t>=timeWindow(1)&t<=timeWindow(2); end
windowIdx=find(fitValid); if numel(windowIdx)<20, error('Not enough finite EE samples.'); end
rawWindow=eePos(windowIdx,1:2); [loopStart,loopEnd]=longestClosedLoop(rawWindow,0.06,2.0);
fitIdx=windowIdx(loopStart:loopEnd); raw=eePos(fitIdx,1:2);
s=[0;cumsum(vecnorm(diff(raw,1,1),2,2))]; [sUnique,uniqueIdx]=unique(s,'stable'); raw=raw(uniqueIdx,:);
sQuery=linspace(0,sUnique(end),240)';
points=[interp1(sUnique,raw(:,1),sQuery),interp1(sUnique,raw(:,2),sQuery)];
xMid=median(points(:,1)); yMin=min(points(:,2)); yMax=max(points(:,2));
q0a=[xMid,yMin+smallRadius,xMid,yMax-largeRadius];
q0b=[xMid,yMax-smallRadius,xMid,yMin+largeRadius];
options=optimset('Display','off','MaxFunEvals',6000,'MaxIter',2500,'TolX',1e-9,'TolFun',1e-10);
cost=@(q)twoCylinderFitCost(q,points,smallRadius,largeRadius,planeLengthGuess);
qa=fminsearch(cost,q0a,options); qb=fminsearch(cost,q0b,options);
if cost(qb)<cost(qa), q=qb; else, q=qa; end
[centerline,denseCurvature]=twoCylinderBoundary(q,smallRadius,largeRadius,720);
idx=find(sampleValid); trueNormal=nan(size(eePos)); trueCurvature=nan(size(t));
previous=[centerline(end-1,:);centerline;centerline(2,:)];
tangent=previous(3:end,:)-previous(1:end-2,:);
outward=[tangent(:,2),-tangent(:,1)]; outward=outward./max(vecnorm(outward,2,2),eps);
distances=nan(numel(idx),1);
for k=1:numel(idx)
    [distances(k),nearest]=min(vecnorm(centerline-eePos(idx(k),1:2),2,2));
    if distances(k)<=0.06
        trueNormal(idx(k),:)=[outward(nearest,:),0]; trueCurvature(idx(k))=denseCurvature(nearest);
    end
end
fit.rms=sqrt(mean(distances(ismember(idx,fitIdx)).^2,'omitnan'));
fit.loopTime=[t(fitIdx(1)) t(fitIdx(end))]; fit.trueNormal=trueNormal;
fit.trueCurvature=trueCurvature; fit.centerline=centerline;
end

function [bestStart,bestEnd]=longestClosedLoop(points,closureTolerance,minLoopLength)
s=[0;cumsum(vecnorm(diff(points,1,1),2,2))]; bestStart=1; bestEnd=size(points,1); bestLength=-inf;
stride=max(1,floor(size(points,1)/1200));
for startIndex=1:stride:size(points,1)
    eligible=find(s-s(startIndex)>=minLoopLength&vecnorm(points-points(startIndex,:),2,2)<=closureTolerance);
    if isempty(eligible), continue; end
    [candidateLength,which]=max(s(eligible)-s(startIndex));
    if candidateLength>bestLength
        bestLength=candidateLength; bestStart=startIndex; bestEnd=eligible(which);
    end
end
if bestLength<minLoopLength, bestStart=1; bestEnd=size(points,1); end
end

function cost=twoCylinderFitCost(q,points,smallRadius,largeRadius,planeLengthGuess)
if any(~isfinite(q))||norm(q(3:4)-q(1:2))<=largeRadius-smallRadius
    cost=1e3+sum(q.^2); return;
end
[boundary,~]=twoCylinderBoundary(q,smallRadius,largeRadius,360);
dPoint=min(pairwiseDistance(points,boundary),[],2); dBoundary=min(pairwiseDistance(boundary,points),[],2);
centerDistance=norm(q(3:4)-q(1:2)); tangentLength=sqrt(max(0,centerDistance^2-(largeRadius-smallRadius)^2));
cost=mean(min(dPoint,0.08).^2)+0.5*mean(min(dBoundary,0.08).^2)+ ...
    0.002*(tangentLength-planeLengthGuess)^2;
end

function [boundary,curvature]=twoCylinderBoundary(q,smallRadius,largeRadius,count)
angles=linspace(0,2*pi,ceil(count/2)+1)'; angles(end)=[];
cloud=[q(1:2)+smallRadius*[cos(angles),sin(angles)]; ...
       q(3:4)+largeRadius*[cos(angles),sin(angles)]];
hull=convhull(cloud(:,1),cloud(:,2),'Simplify',true); hull(end)=[]; polygon=cloud(hull,:);
s=[0;cumsum(vecnorm(diff([polygon;polygon(1,:)],1,1),2,2))];
sQuery=linspace(0,s(end),count+1)'; sQuery(end)=[]; closed=[polygon;polygon(1,:)];
boundary=[interp1(s,closed(:,1),sQuery),interp1(s,closed(:,2),sQuery)];
smallResidual=abs(vecnorm(boundary-q(1:2),2,2)-smallRadius);
largeResidual=abs(vecnorm(boundary-q(3:4),2,2)-largeRadius);
curvature=zeros(count,1); curvature(smallResidual<2e-3)=1/smallRadius;
curvature(largeResidual<2e-3)=1/largeRadius;
end

function distance=pairwiseDistance(a,b)
delta=reshape(a,[],1,2)-reshape(b,1,[],2); distance=sqrt(sum(delta.^2,3));
end

function folder=activeScriptDirectory()
folder='';
try
    activeFile=matlab.desktop.editor.getActiveFilename;
    if ~isempty(activeFile), folder=fileparts(activeFile); end
catch
end
if isempty(folder)
    thisFile=mfilename('fullpath'); if ~isempty(thisFile), folder=fileparts(thisFile); end
end
if isempty(folder), folder=pwd; end
end
